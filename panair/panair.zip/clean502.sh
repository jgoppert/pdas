# Shell script to delete the temporary files produced by PanAir
# Last modified  >> 11 March 2009
#rm agps
#rm ffm
#rm ffmf
#rm fmgp
#rm fort.88
#rm fslout
#rm ft??
#rm iflggp
#rm ispggp
#rm mspnt1
#rm news
#rm nli???
rm rwms??
#rm stmlin


